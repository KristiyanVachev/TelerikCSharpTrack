﻿namespace FurnitureManufacturer.Interfaces.Engine
{
    public interface IFurnitureManufacturerEngine
    {
        void Start();
    }
}
